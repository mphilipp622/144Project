#!/bin/sh
make;
printf "\n";
./myapp.exe "$@";